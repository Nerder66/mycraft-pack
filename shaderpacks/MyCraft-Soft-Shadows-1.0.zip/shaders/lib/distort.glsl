vec3 distortShadow(vec3 p) {
    float d = length(p.xy);
    float f = d * 0.88 + 0.12;
    return vec3(p.xy / f, p.z * 0.25);
}
