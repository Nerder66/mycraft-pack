varying vec4 glcolor;
varying vec2 lmcoord;
varying vec3 playerPos;
varying vec3 viewPos;
uniform mat4 gbufferModelViewInverse;
void main() {
    gl_Position = ftransform();
    glcolor = gl_Color;
    lmcoord = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    vec4 vp = gl_ModelViewMatrix * gl_Vertex;
    viewPos = vp.xyz;
    playerPos = (gbufferModelViewInverse * vp).xyz;
}
