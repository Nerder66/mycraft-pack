varying vec4 glcolor;
varying vec3 playerPos;
uniform mat4 gbufferModelViewInverse;
void main() { gl_Position = ftransform(); glcolor = gl_Color; playerPos = (gbufferModelViewInverse * (gl_ModelViewMatrix * gl_Vertex)).xyz; }
