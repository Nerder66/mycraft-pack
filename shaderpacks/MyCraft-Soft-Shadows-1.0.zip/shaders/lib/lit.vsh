#include "/lib/settings.glsl"
varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 glcolor;
varying vec3 playerPos;
varying vec3 viewNormal;
uniform mat4 gbufferModelViewInverse;
void main() {
    gl_Position = ftransform();
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    lmcoord = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    glcolor = gl_Color;
    vec4 vp = gl_ModelViewMatrix * gl_Vertex;
    playerPos = (gbufferModelViewInverse * vp).xyz;
    viewNormal = gl_NormalMatrix * gl_Normal;
}
