uniform sampler2DShadow shadowtex0;
uniform mat4 shadowModelView;
uniform mat4 shadowProjection;
uniform vec3 shadowLightPosition;
uniform vec3 cameraPosition;
uniform float rainStrength;
uniform int worldTime;
uniform mat4 gbufferModelViewInverse;
#include "/lib/distort.glsl"

// 1 = lit by the sun (or moon), 0 = in shadow
float sunLight(vec3 playerPos, vec3 viewNormal, float skyLight) {
    if (skyLight < 0.05) return 1.0;                         // deep inside: no sun shadows, vanilla light only
    float dist = length(playerPos);
    if (dist > shadowDistance) return 1.0;
    vec3 lightDir = normalize(shadowLightPosition);
    float ndl = dot(normalize(viewNormal), lightDir);
    vec3 worldNormal = normalize(mat3(gbufferModelViewInverse) * viewNormal);
    // step half a texture pixel out of the surface first, so the test point never lands inside its own block (no speckles)
    vec3 world = playerPos + cameraPosition + worldNormal * (1.0 / 32.0);
#ifdef PIXEL_SHADOWS
    world = (floor(world * 16.0) + 0.5) / 16.0;                // snap to the centre of the texture pixel, like the rest of Minecraft
#endif
    vec3 p = world - cameraPosition;
    vec4 sp = shadowProjection * (shadowModelView * vec4(p, 1.0));
    float bias = 0.0004 + 0.0006 * (1.0 - clamp(ndl, 0.0, 1.0));
    vec3 d = distortShadow(sp.xyz);
    d = d * 0.5 + 0.5;
    d.z -= bias;
    float s;
#ifdef SOFT_EDGES
    float px = 1.0 / float(shadowMapResolution);
    s = 0.0;
    s += shadow2D(shadowtex0, d + vec3(-0.5, -0.5, 0.0) * px).r;
    s += shadow2D(shadowtex0, d + vec3( 0.5, -0.5, 0.0) * px).r;
    s += shadow2D(shadowtex0, d + vec3(-0.5,  0.5, 0.0) * px).r;
    s += shadow2D(shadowtex0, d + vec3( 0.5,  0.5, 0.0) * px).r;
    s *= 0.25;
#else
    s = shadow2D(shadowtex0, d).r;
#endif
    if (ndl <= 0.0) s = 0.0;                                   // facing away from the sun
    float edge = smoothstep(shadowDistance * 0.8, shadowDistance, dist);
    return mix(s, 1.0, edge);
}

// how much a shadow darkens: strongest at noon, softer at dawn/dusk and under the moon, fades in rain and indoors
float shadowAmount(float skyLight) {
    float t = mod(float(worldTime), 24000.0);
    float day = (t < 12500.0 || t > 23500.0) ? 1.0 : 0.35;   // moonlight shadows are fainter
    float sky = smoothstep(0.4, 0.95, skyLight);
    return SHADOW_STRENGTH * day * sky * (1.0 - 0.8 * rainStrength);
}
