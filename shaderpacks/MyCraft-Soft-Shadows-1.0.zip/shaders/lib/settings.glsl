#define SHADOW_STRENGTH 0.62 // How dark sun shadows get [0.30 0.40 0.45 0.50 0.55 0.62 0.70 0.80]
#define PIXEL_SHADOWS // Shadows snap to the block's pixel grid, like the rest of Minecraft
#define SOFT_EDGES // Slightly soft shadow edges
const int shadowMapResolution = 1536; // [1024 1536 2048 3072 4096]
const float shadowDistance = 64.0; // [48.0 64.0 80.0 96.0 128.0 160.0]
const float shadowDistanceRenderMul = 1.0;
const bool shadowHardwareFiltering = true;
const float sunPathRotation = -20.0;
