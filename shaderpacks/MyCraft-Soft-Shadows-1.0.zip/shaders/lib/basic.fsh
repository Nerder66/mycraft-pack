#include "/lib/fog.glsl"
varying vec4 glcolor;
varying vec3 playerPos;
void main() {
    vec4 c = glcolor;
#ifdef SKY
    float f = clamp((length(playerPos) - fogStart) / max(fogEnd - fogStart, 0.0001), 0.0, 1.0);
    c.rgb = mix(c.rgb, fogColor, f);
#else
    c.rgb = mix(c.rgb, fogColor, fogFactor(vec3(0.0), playerPos));
#endif
    /* DRAWBUFFERS:0 */
    gl_FragData[0] = c;
}
