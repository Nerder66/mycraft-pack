uniform vec3 fogColor;
uniform float fogStart;
uniform float fogEnd;
// vanilla-style linear fog, cylinder-shaped like vanilla terrain fog
float fogFactor(vec3 viewPos, vec3 playerPos) {
    float d = max(length(playerPos.xz), abs(playerPos.y));
    return clamp((d - fogStart) / max(fogEnd - fogStart, 0.0001), 0.0, 1.0);
}
