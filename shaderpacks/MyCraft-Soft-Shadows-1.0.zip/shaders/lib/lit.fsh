#include "/lib/settings.glsl"
uniform sampler2D gtexture;
uniform sampler2D lightmap;
#ifdef ENTITY
uniform vec4 entityColor;
#endif
#include "/lib/fog.glsl"
#ifdef SHADOWS
#include "/lib/shadow.glsl"
#endif
varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 glcolor;
varying vec3 playerPos;
varying vec3 viewNormal;
void main() {
    vec4 c = texture2D(gtexture, texcoord) * glcolor;
    if (c.a < ALPHA_CUT) discard;
#ifdef ENTITY
    c.rgb = mix(c.rgb, entityColor.rgb, entityColor.a);
#endif
    vec3 light = texture2D(lightmap, lmcoord).rgb;
#ifdef SHADOWS
    float sky = clamp((lmcoord.y - 0.03125) * 1.0667, 0.0, 1.0);
    float block = clamp((lmcoord.x - 0.03125) * 1.0667, 0.0, 1.0);
    float lit = sunLight(playerPos, viewNormal, sky);
    float amt = shadowAmount(sky);
    light *= mix(1.0, 1.0 - amt, (1.0 - lit) * (1.0 - 0.85 * block));
#endif
    c.rgb *= light;
    c.rgb = mix(c.rgb, fogColor, fogFactor(vec3(0.0), playerPos));
    /* DRAWBUFFERS:0 */
    gl_FragData[0] = c;
}
