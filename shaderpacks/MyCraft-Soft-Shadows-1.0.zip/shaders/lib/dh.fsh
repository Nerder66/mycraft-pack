uniform sampler2D lightmap;
uniform sampler2D depthtex0;
uniform float far;
uniform float viewWidth;
uniform float viewHeight;
uniform int dhRenderDistance;
#include "/lib/fog.glsl"
varying vec4 glcolor;
varying vec2 lmcoord;
varying vec3 playerPos;
varying vec3 viewPos;
void main() {
    // the real chunks are drawn up close: only draw the far terrain beyond them (with a little dithered overlap)
    float dither = fract(dot(gl_FragCoord.xy, vec2(0.0671, 0.00583)) * 52.98);
    if (length(viewPos) < far - 16.0 + dither * 12.0) discard;
#ifdef DH_WATER
    if (texture2D(depthtex0, gl_FragCoord.xy / vec2(viewWidth, viewHeight)).r < 1.0) discard;   // something nearer is already there
#endif
    vec4 c = glcolor;
    c.rgb *= texture2D(lightmap, lmcoord).rgb;
    float lod = smoothstep(float(dhRenderDistance) * 0.55, float(dhRenderDistance), length(playerPos));
    float storm = fogEnd < far * 0.6 ? fogFactor(vec3(0.0), playerPos) : 0.0;   // sandstorm, blizzard: the far land disappears too
    c.rgb = mix(c.rgb, fogColor, max(lod, storm));
    /* DRAWBUFFERS:0 */
    gl_FragData[0] = c;
}
