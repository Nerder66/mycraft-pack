#version 120
#define SKY
#include "/lib/basic.fsh"
