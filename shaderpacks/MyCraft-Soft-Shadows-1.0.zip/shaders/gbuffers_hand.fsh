#version 120
#define ALPHA_CUT 0.1
#include "/lib/lit.fsh"
