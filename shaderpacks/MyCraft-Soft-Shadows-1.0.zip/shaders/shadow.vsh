#version 120
#include "/lib/settings.glsl"
#include "/lib/distort.glsl"
varying vec2 texcoord;
void main() { vec4 p = ftransform(); p.xyz = distortShadow(p.xyz); gl_Position = p; texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy; }
