#version 120
#define ALPHA_CUT 0.004
#include "/lib/lit.fsh"
