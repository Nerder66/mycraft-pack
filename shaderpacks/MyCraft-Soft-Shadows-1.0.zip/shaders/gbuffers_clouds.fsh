#version 120
uniform sampler2D gtexture;
#include "/lib/fog.glsl"
varying vec2 texcoord;
varying vec4 glcolor;
varying vec3 playerPos;
void main() {
    vec4 c = texture2D(gtexture, texcoord) * glcolor;
    if (c.a < 0.004) discard;
    float f = clamp((length(playerPos) - fogStart) / max(fogEnd - fogStart, 0.0001), 0.0, 1.0);
    c.rgb = mix(c.rgb, fogColor, f);
    /* DRAWBUFFERS:0 */
    gl_FragData[0] = c;
}
