#version 120
#define SHADOWS
#define ALPHA_CUT 0.004
#include "/lib/lit.fsh"
